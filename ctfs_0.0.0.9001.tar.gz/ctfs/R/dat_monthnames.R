#' Object assumed to be crucial. In `utilities.R, the original documen...
#' 
#' Object assumed to be crucial. In `utilities.R, the original documentation of
#' the CTFSRPackage states:
#' 
#' ``` # This is supplemental code necessary for the functinos to run. 
#' MONTHNAMES = c( 
#' 'Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec' ) 
#' ```
#'
'MONTHNAMES'
