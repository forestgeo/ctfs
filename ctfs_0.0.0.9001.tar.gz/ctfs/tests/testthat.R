library(testthat)
library(ctfs)

test_check("ctfs")
